package cn.edu.buaa.crypto.encryption.CDABACE;

public class Pai {
}
