package cn.edu.buaa.crypto.encryption.CDABACE;

import it.unisa.dia.gas.jpbc.Element;

public class MSK_ra {
    Element gAlpha;

    public MSK_ra(Element gAlpha) {
        this.gAlpha = gAlpha;
    }
}
