package cn.edu.buaa.crypto.encryption.CDABACE;

import it.unisa.dia.gas.jpbc.Element;

public class CRS {
    public Element g0;
    public CRS(Element g0){
        this.g0 = g0;
    }
}
