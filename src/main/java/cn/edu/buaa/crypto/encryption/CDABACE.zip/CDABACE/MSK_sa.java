package cn.edu.buaa.crypto.encryption.CDABACE;

import it.unisa.dia.gas.jpbc.Element;

public class MSK_sa {
    Element v;

    public MSK_sa(Element v) {
        this.v = v;
    }
}
